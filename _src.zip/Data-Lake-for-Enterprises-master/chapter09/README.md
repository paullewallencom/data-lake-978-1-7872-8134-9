# Chapter 9 - Data Store using Apache Hadoop

This folder contains the various code samples explained in **Chapter 9** of the book - *Data Lake for Enterprises*. 

It contains multiple projects, the context of each one and its working would be explained in detail while traversing through the example section in the chapter.  

The code can be build from root of the chapter09 folder by executing the below command:  

`mvn clean install`

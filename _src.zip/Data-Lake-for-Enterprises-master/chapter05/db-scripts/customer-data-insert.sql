INSERT  INTO customer values(0,'tomcy','john','1985-10-20');
INSERT  INTO customer values(1,'rahul','dev','1989-08-15');
INSERT  INTO customer values(2,'pankaj','misra','1982-08-10');
INSERT  INTO customer values(3,'devi','lal','1990-05-06');
INSERT  INTO customer values(4,'john','doe','1992-06-25');

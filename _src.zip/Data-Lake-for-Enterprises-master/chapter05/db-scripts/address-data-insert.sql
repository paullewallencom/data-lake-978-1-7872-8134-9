
INSERT INTO address (id, custumer_id, street1, street2, city, state, country, zip_pin_postal_code) VALUES (0, 0, 'd-40', 'chavez street', 'trivandrum', 'kerala', 'india', '778908');
INSERT INTO address (id, custumer_id, street1, street2, city, state, country, zip_pin_postal_code) VALUES (1, 1, 'l-90', 'cooper street', 'mumbai', 'maharashtra', 'india', '400056');
INSERT INTO address (id, custumer_id, street1, street2, city, state, country, zip_pin_postal_code) VALUES (2, 2, 'a-47', 'sector-11', 'noida', 'uttar pradesh', 'india', '201311');
INSERT INTO address (id, custumer_id, street1, street2, city, state, country, zip_pin_postal_code) VALUES (3, 3, 'r-98', 'sector-37', 'gurgaon', 'haryana', 'india', '122021');
INSERT INTO address (id, custumer_id, street1, street2, city, state, country, zip_pin_postal_code) VALUES (4, 4, '201', 'high street', 'austin', 'texas', 'us', '41101');

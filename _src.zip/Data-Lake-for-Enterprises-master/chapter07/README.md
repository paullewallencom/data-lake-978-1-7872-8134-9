# Chapter 7 - Messaging Layer using Apache Kafka

This folder contains the various code samples explained in **Chapter 7** of the book - *Data Lake for Enterprises*. 

The code can be build from root of the chapter07 folder by executing the below command:  

`mvn clean install`

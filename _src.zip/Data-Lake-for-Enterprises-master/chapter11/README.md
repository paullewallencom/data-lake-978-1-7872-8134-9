# Chapter 11 - Data Lake Components Working Together

This folder contains the various code samples explained in **Chapter 11** of the book - *Data Lake for Enterprises*. 

The code can be build from root of the chapter11 folder by executing the below command:  

`mvn clean install`

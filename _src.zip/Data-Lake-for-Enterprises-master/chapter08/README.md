# Chapter 8 - Data Processing using Apache Flink

This folder contains the various code samples explained in **Chapter 8** of the book - *Data Lake for Enterprises*. 

It contains multiple projects, the context of each one and its working would be explained in detail while traversing through the example section in the chapter.  

The code can be build from root of the chapter08 folder by executing the below command:  

`mvn clean install`

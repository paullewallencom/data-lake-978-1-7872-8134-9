package com.laketravels.ch08.generator.web;

/**
 * Created by pankajmisra on 3/17/17.
 */
public enum DataType {
    LOCATION, CONTACT
}
